import struct
import re

# Leer el archivo .txt
def leer_sql(nombre_archivo):
    with open(nombre_archivo, 'r') as f:
        return f.read()

# Interpretar la estructura SQL
def parse_create_table(sql):
    estructura = []
    for linea in sql.splitlines():
        linea = linea.strip().strip(',').strip(';').lower()
        if not linea or 'create table' in linea or linea.startswith("(") or linea.startswith(")"):
            continue
        linea = linea.split('not null')[0].split('primary key')[0].strip()
        match = re.match(r'^([a-z_][a-z0-9_]*)\s+([a-z]+)(?:\(([^)]+)\))?', linea)
        if not match:
            continue
        nombre, tipo, params = match.groups()
        if tipo == "varchar" and params:
            estructura.append((nombre, f"{int(params)}s"))
        elif tipo in ("int", "integer"):
            estructura.append((nombre, "i"))
        elif tipo == "decimal":
            estructura.append((nombre, "d"))
    return estructura

# Empaquetar a binario
def empaquetar(estructura, datos):
    formato = '=' + ''.join(tipo for _, tipo in estructura)
    valores = []
    for (_, tipo), val in zip(estructura, datos):
        if tipo.endswith('s'):
            tam = int(tipo[:-1])
            valores.append(val.encode('utf-8')[:tam].ljust(tam, b'\x00'))
        else:
            valores.append(val)
    return struct.pack(formato, *valores)

# Desempaquetar desde binario
def desempaquetar(estructura, registro_bytes):
    formato = '=' + ''.join(tipo for _, tipo in estructura)
    valores = struct.unpack(formato, registro_bytes)
    resultado = []
    for (_, tipo), val in zip(estructura, valores):
        if tipo.endswith('s'):
            resultado.append(val.decode('utf-8').rstrip('\x00'))
        else:
            resultado.append(val)
    return resultado

# Prueba directa
if __name__ == "__main__":
    archivo = "struct_table.txt"  # debe estar en la misma carpeta
    sql = leer_sql(archivo)
    estructura = parse_create_table(sql)

    print("📐 Estructura detectada:")
    for campo, tipo in estructura:
        print(f" - {campo.upper():<10}: {tipo}")

    datos = (1, "Teclado USB", 50.0, 9.0, 59.0)
    binario = empaquetar(estructura, datos)
    recuperado = desempaquetar(estructura, binario)

    print(f"\n🔧 Tamaño total: {len(binario)} bytes")
    print(f"📦 Datos originales:   {datos}")
    print(f"📤 Datos recuperados:  {recuperado}")
